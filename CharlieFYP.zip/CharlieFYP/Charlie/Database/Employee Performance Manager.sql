--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7
-- Dumped by pg_dump version 10.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Attendance Information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Attendance Information" (
    "Attendance ID" bigint NOT NULL,
    "Employee ID" text,
    "Date" date,
    "In" time without time zone,
    "Out" time without time zone,
    "Remarks" text,
    "Status" text
);


ALTER TABLE public."Attendance Information" OWNER TO postgres;

--
-- Name: Attendance Information_Attendance ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Attendance Information_Attendance ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Attendance Information_Attendance ID_seq" OWNER TO postgres;

--
-- Name: Attendance Information_Attendance ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Attendance Information_Attendance ID_seq" OWNED BY public."Attendance Information"."Attendance ID";


--
-- Name: Employee Profile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employee Profile" (
    "Employee ID" text NOT NULL,
    "Name" text,
    "Date of Birth" date,
    "Gender" text,
    "Position" text,
    "Department" text,
    "Direct Manager" text
);


ALTER TABLE public."Employee Profile" OWNER TO postgres;

--
-- Name: Performance Review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Performance Review" (
    "Review ID" bigint NOT NULL,
    "Review Date" date,
    "Employee ID" text,
    "Attendance Performance" double precision,
    "Resource Usage Performance" double precision,
    "Work Delivery Performance" double precision,
    "Performance Formula" text,
    "Final Performance Index" double precision
);


ALTER TABLE public."Performance Review" OWNER TO postgres;

--
-- Name: Performance Review_Review ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Performance Review_Review ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Performance Review_Review ID_seq" OWNER TO postgres;

--
-- Name: Performance Review_Review ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Performance Review_Review ID_seq" OWNED BY public."Performance Review"."Review ID";


--
-- Name: Resource Information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Resource Information" (
    "Resource ID" bigint NOT NULL,
    "Employee ID" text,
    "Date" date,
    "Detection" text,
    "Remark" text,
    "Status" text,
    "Hours" integer
);


ALTER TABLE public."Resource Information" OWNER TO postgres;

--
-- Name: Resource Information_Resource ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Resource Information_Resource ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Resource Information_Resource ID_seq" OWNER TO postgres;

--
-- Name: Resource Information_Resource ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Resource Information_Resource ID_seq" OWNED BY public."Resource Information"."Resource ID";


--
-- Name: System Settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."System Settings" (
    "ID" bigint NOT NULL,
    "In Time" time without time zone,
    "In Tolerance" integer,
    "Out Time" time without time zone,
    "Out Tolerance" integer,
    "Detection Tolerance" integer,
    "Weight Per Detection" integer,
    "Maximum Performance" integer
);


ALTER TABLE public."System Settings" OWNER TO postgres;

--
-- Name: System Settings_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."System Settings_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."System Settings_ID_seq" OWNER TO postgres;

--
-- Name: System Settings_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."System Settings_ID_seq" OWNED BY public."System Settings"."ID";


--
-- Name: User Profile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User Profile" (
    "Username" text NOT NULL,
    "Password" text,
    "Name" text
);


ALTER TABLE public."User Profile" OWNER TO postgres;

--
-- Name: Work Delivery Information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Work Delivery Information" (
    "Work Delivery ID" bigint NOT NULL,
    "Employee ID" text,
    "Date" date,
    "Activity/Task" text,
    "Difficulty" integer,
    "Performance" integer
);


ALTER TABLE public."Work Delivery Information" OWNER TO postgres;

--
-- Name: Work Delivery Information_Work Delivery ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Work Delivery Information_Work Delivery ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Work Delivery Information_Work Delivery ID_seq" OWNER TO postgres;

--
-- Name: Work Delivery Information_Work Delivery ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Work Delivery Information_Work Delivery ID_seq" OWNED BY public."Work Delivery Information"."Work Delivery ID";


--
-- Name: Attendance Information Attendance ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Attendance Information" ALTER COLUMN "Attendance ID" SET DEFAULT nextval('public."Attendance Information_Attendance ID_seq"'::regclass);


--
-- Name: Performance Review Review ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Performance Review" ALTER COLUMN "Review ID" SET DEFAULT nextval('public."Performance Review_Review ID_seq"'::regclass);


--
-- Name: Resource Information Resource ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Resource Information" ALTER COLUMN "Resource ID" SET DEFAULT nextval('public."Resource Information_Resource ID_seq"'::regclass);


--
-- Name: System Settings ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."System Settings" ALTER COLUMN "ID" SET DEFAULT nextval('public."System Settings_ID_seq"'::regclass);


--
-- Name: Work Delivery Information Work Delivery ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Work Delivery Information" ALTER COLUMN "Work Delivery ID" SET DEFAULT nextval('public."Work Delivery Information_Work Delivery ID_seq"'::regclass);


--
-- Data for Name: Attendance Information; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Attendance Information" VALUES (40, 'A2123', '2018-04-04', '09:03:00', '16:55:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (41, 'A2123', '2018-04-10', '08:59:00', '16:46:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (42, 'A2123', '2018-04-15', '09:00:00', '17:10:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (43, 'A2123', '2018-05-05', '11:00:00', '17:15:00', 'Meeting from home', 'Good');
INSERT INTO public."Attendance Information" VALUES (44, 'A2123', '2018-05-10', '09:25:00', '17:01:00', 'Late without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (45, 'A2123', '2018-05-15', '08:49:00', '16:54:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (46, 'A2123', '2018-04-20', '08:40:00', '18:02:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (1, 'A2123', '2018-01-02', '09:00:00', '17:00:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (2, 'A2123', '2018-01-03', '09:00:00', '17:10:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (3, 'A2123', '2018-01-04', '08:40:00', '17:10:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (4, 'A2123', '2018-01-10', '09:10:00', '17:00:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (5, 'A2123', '2018-02-05', '09:20:00', '17:20:00', 'Late in but cover back', 'Good');
INSERT INTO public."Attendance Information" VALUES (6, 'A2123', '2018-02-07', '09:00:00', '17:00:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (7, 'A2123', '2018-02-08', '09:30:00', '17:00:00', 'Late in without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (8, 'A2123', '2018-02-14', '09:00:00', '17:20:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (9, 'A2123', '2018-03-11', '08:40:00', '14:00:00', 'Early back without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (10, 'A2123', '2018-03-14', '09:05:00', '18:00:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (11, 'A2123', '2018-03-19', '08:40:00', '16:09:00', 'Early back without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (12, 'A2123', '2018-03-22', '09:10:00', '16:58:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (13, 'A1234', '2018-01-02', '07:30:00', '19:00:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (14, 'A1234', '2018-01-03', '08:40:00', '17:00:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (15, 'A1234', '2018-01-04', '11:00:00', '17:00:00', 'Onsite to customer site', 'Good');
INSERT INTO public."Attendance Information" VALUES (16, 'A1234', '2018-01-10', '09:30:00', '16:50:00', 'Late in without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (17, 'A1234', '2018-02-05', '09:00:00', '16:30:00', 'Early back without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (18, 'A1234', '2018-02-07', '08:48:00', '17:11:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (47, 'A2123', '2018-05-20', '08:55:00', '14:30:00', 'Early back but work from home', 'Normal');
INSERT INTO public."Attendance Information" VALUES (48, 'A2123', '2018-06-01', '09:34:00', '17:03:00', 'Late in without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (49, 'A2123', '2018-06-06', '08:40:00', '17:19:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (50, 'A2123', '2018-06-10', '09:05:00', '17:09:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (51, 'A2123', '2018-06-18', '08:45:00', '18:03:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (52, 'A2123', '2018-07-02', '08:46:00', '17:52:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (53, 'A2123', '2018-07-08', '08:59:00', '16:10:00', 'Early back without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (54, 'A2123', '2018-07-15', '09:01:00', '16:30:00', 'Early back without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (19, 'A1234', '2018-02-08', '08:00:00', '16:30:00', 'Early back but early in cover', 'Good');
INSERT INTO public."Attendance Information" VALUES (55, 'A2123', '2018-07-22', '08:36:00', '17:02:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (56, 'A2123', '2018-08-03', '08:56:00', '17:02:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (20, 'A1234', '2018-02-14', '08:49:00', '16:10:00', 'Early back without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (57, 'A2123', '2018-08-08', '12:30:00', '17:52:00', 'Late in but work from home', 'Good');
INSERT INTO public."Attendance Information" VALUES (21, 'A1234', '2018-03-11', '09:40:00', '17:10:00', 'Late in without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (22, 'A1234', '2018-03-14', '09:10:00', '17:30:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (23, 'A1234', '2018-03-19', '10:00:00', '17:30:00', 'Late in without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (24, 'A1234', '2018-03-22', '09:30:00', '17:00:00', 'Late in without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (58, 'A2123', '2018-08-14', '09:50:00', '17:59:00', 'Late in but cover back', 'Good');
INSERT INTO public."Attendance Information" VALUES (59, 'A2123', '2018-08-20', '09:30:00', '17:10:00', 'Late in without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (60, 'A2123', '2018-09-01', '08:00:00', '17:12:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (61, 'A2123', '2018-09-06', '09:05:00', '16:49:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (62, 'A2123', '2018-09-13', '08:44:00', '16:00:00', 'Early back without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (63, 'A2123', '2018-09-27', '07:50:00', '17:20:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (64, 'A2123', '2018-10-01', '08:50:00', '17:09:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (65, 'A2123', '2018-10-06', '08:20:00', '17:22:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (66, 'A2123', '2018-10-10', '09:02:00', '17:22:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (67, 'A2123', '2018-10-28', '08:21:00', '16:50:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (68, 'A2123', '2018-11-03', '09:00:00', '16:30:00', 'Early back without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (69, 'A2123', '2018-11-11', '07:30:00', '16:50:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (70, 'A2123', '2018-11-19', '08:33:00', '17:32:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (71, 'A2123', '2018-11-23', '08:42:00', '18:20:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (72, 'A2123', '2018-12-03', '08:37:00', '17:07:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (74, 'A2123', '2018-12-17', '09:10:00', '17:12:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (75, 'A2123', '2018-12-22', '09:40:00', '18:11:00', 'Late in but cover back', 'Good');
INSERT INTO public."Attendance Information" VALUES (73, 'A2123', '2018-12-09', '10:30:00', '17:20:00', 'Late in but work from home', 'Good');
INSERT INTO public."Attendance Information" VALUES (76, 'A1234', '2018-04-04', '00:00:00', '00:00:00', 'On Leave', 'Good');
INSERT INTO public."Attendance Information" VALUES (77, 'A1234', '2018-04-10', '08:49:00', '18:01:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (78, 'A1234', '2018-04-15', '08:32:00', '05:03:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (79, 'A1234', '2018-04-20', '09:09:00', '17:44:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (80, 'A1234', '2018-05-05', '08:55:00', '16:49:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (81, 'A1234', '2018-05-10', '09:37:00', '17:00:00', 'Late in without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (82, 'A1234', '2018-05-15', '09:10:00', '17:49:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (83, 'A1234', '2018-05-20', '08:29:00', '17:01:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (84, 'A1234', '2018-06-01', '09:00:00', '17:11:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (85, 'A1234', '2018-06-06', '09:04:00', '17:28:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (86, 'A1234', '2018-06-10', '09:10:00', '17:10:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (87, 'A1234', '2018-06-18', '08:22:00', '16:58:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (88, 'A1234', '2018-07-02', '00:00:00', '00:00:00', 'Sick Leave', 'Good');
INSERT INTO public."Attendance Information" VALUES (89, 'A1234', '2018-07-08', '08:30:00', '17:30:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (90, 'A1234', '2018-07-15', '08:48:00', '17:07:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (91, 'A1234', '2018-07-22', '09:30:00', '18:10:00', 'Late in but cover back', 'Good');
INSERT INTO public."Attendance Information" VALUES (93, 'A1234', '2018-08-08', '08:02:00', '17:00:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (92, 'A1234', '2018-08-03', '09:20:00', '17:22:00', 'Late in but cover back', 'Good');
INSERT INTO public."Attendance Information" VALUES (94, 'A1234', '2018-08-14', '08:49:00', '17:02:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (95, 'A1234', '2018-08-20', '10:01:00', '17:07:00', 'Late in without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (96, 'A1234', '2018-09-01', '08:55:00', '17:05:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (97, 'A1234', '2018-09-06', '09:03:00', '17:08:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (98, 'A1234', '2018-09-13', '11:03:00', '17:29:00', 'Late in but meeting from home', 'Good');
INSERT INTO public."Attendance Information" VALUES (99, 'A1234', '2018-09-27', '09:12:00', '17:43:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (100, 'A1234', '2018-10-01', '08:48:00', '16:51:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (101, 'A1234', '2018-10-06', '09:01:00', '17:27:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (102, 'A1234', '2018-10-10', '08:53:00', '17:33:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (103, 'A1234', '2018-10-28', '08:00:00', '16:30:00', 'Early back but cover back', 'Good');
INSERT INTO public."Attendance Information" VALUES (104, 'A1234', '2018-11-03', '08:48:00', '17:21:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (105, 'A1234', '2018-11-11', '08:49:00', '16:03:00', 'Early back without reason', 'Bad');
INSERT INTO public."Attendance Information" VALUES (106, 'A1234', '2018-11-19', '08:11:00', '16:49:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (107, 'A1234', '2018-11-23', '08:52:00', '18:09:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (108, 'A1234', '2018-12-03', '09:11:00', '18:23:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (109, 'A1234', '2018-12-09', '09:55:00', '18:30:00', 'Late in but cover back', 'Good');
INSERT INTO public."Attendance Information" VALUES (110, 'A1234', '2018-12-17', '08:40:00', '17:20:00', 'Normal', 'Good');
INSERT INTO public."Attendance Information" VALUES (111, 'A1234', '2018-12-22', '08:59:00', '17:01:00', 'Normal', 'Good');


--
-- Data for Name: Employee Profile; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Employee Profile" VALUES ('A1234', 'Susan', '1990-07-11', 'Female', 'Engineer', 'R & D', 'Mary');
INSERT INTO public."Employee Profile" VALUES ('A2123', 'John', '1993-03-25', 'Male', 'IT Engineer', 'IT', 'Bruce');


--
-- Data for Name: Performance Review; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Performance Review" VALUES (10, '2018-05-01', 'A2123', 50, 96, 83.333333333333002, 'Standard', 80.466666666666995);
INSERT INTO public."Performance Review" VALUES (11, '2018-06-01', 'A2123', 75, 97, 83.333333333333002, 'Standard', 85.766666666667007);
INSERT INTO public."Performance Review" VALUES (12, '2018-07-01', 'A2123', 50, 95, 83.333333333333002, 'Standard', 80.166666666666998);
INSERT INTO public."Performance Review" VALUES (13, '2018-08-01', 'A2123', 75, 96, 83.333333333333002, 'Standard', 85.466666666666995);
INSERT INTO public."Performance Review" VALUES (14, '2018-09-01', 'A2123', 75, 96, 86.666666666666998, 'Standard', 87.133333333332999);
INSERT INTO public."Performance Review" VALUES (15, '2018-10-01', 'A2123', 100, 100, 88.888888888888999, 'Standard', 94.444444444444002);
INSERT INTO public."Performance Review" VALUES (16, '2018-11-01', 'A2123', 75, 94, 66.666666666666998, 'Standard', 76.533333333333005);
INSERT INTO public."Performance Review" VALUES (17, '2018-12-01', 'A2123', 100, 96, 66.666666666666998, 'Standard', 82.133333333332999);
INSERT INTO public."Performance Review" VALUES (18, '2018-01-01', 'A1234', 75, 94, 66.666666666666998, 'Standard', 76.533333333333005);
INSERT INTO public."Performance Review" VALUES (5, '2018-01-01', 'A2123', 100, 95, 66.666666666666998, 'Standard', 81.833333333333002);
INSERT INTO public."Performance Review" VALUES (7, '2018-02-01', 'A2123', 75, 98, 100, 'Standard', 94.400000000000006);
INSERT INTO public."Performance Review" VALUES (8, '2018-03-01', 'A2123', 50, 96, 86.666666666666998, 'Standard', 82.133333333332999);
INSERT INTO public."Performance Review" VALUES (9, '2018-04-01', 'A2123', 100, 96, 50, 'Standard', 73.799999999999997);
INSERT INTO public."Performance Review" VALUES (19, '2018-02-01', 'A1234', 50, 96, 83.333333333333002, 'Standard', 80.466666666666995);
INSERT INTO public."Performance Review" VALUES (20, '2018-03-01', 'A1234', 25, 99, 83.333333333333002, 'Standard', 76.366666666667001);
INSERT INTO public."Performance Review" VALUES (21, '2018-04-01', 'A1234', 100, 100, 66.666666666666998, 'Standard', 83.333333333333002);
INSERT INTO public."Performance Review" VALUES (22, '2018-05-01', 'A1234', 75, 98, 60, 'Standard', 74.400000000000006);
INSERT INTO public."Performance Review" VALUES (23, '2018-06-01', 'A1234', 100, 100, 80, 'Standard', 90);
INSERT INTO public."Performance Review" VALUES (24, '2018-07-01', 'A1234', 100, 99, 66.666666666666998, 'Standard', 83.033333333333005);
INSERT INTO public."Performance Review" VALUES (25, '2018-08-01', 'A1234', 75, 100, 80, 'Standard', 85);
INSERT INTO public."Performance Review" VALUES (26, '2018-09-01', 'A1234', 100, 99, 100, 'Standard', 99.700000000000003);
INSERT INTO public."Performance Review" VALUES (27, '2018-10-01', 'A1234', 100, 100, 83.333333333333002, 'Standard', 91.666666666666998);
INSERT INTO public."Performance Review" VALUES (28, '2018-11-01', 'A1234', 75, 100, 80, 'Standard', 85);
INSERT INTO public."Performance Review" VALUES (29, '2018-12-01', 'A1234', 100, 95, 50, 'Standard', 73.5);


--
-- Data for Name: Resource Information; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Resource Information" VALUES (27, 'A2123', '2018-03-03', 'Using social media Watsapp application', 'Illegal/Non-compliance chatting application', 'Bad', 2);
INSERT INTO public."Resource Information" VALUES (28, 'A2123', '2018-03-09', 'Using social media Watsapp application', 'Illegal/Non-compliance chatting application', 'Bad', 3);
INSERT INTO public."Resource Information" VALUES (29, 'A2123', '2018-05-09', 'Access illegal music download website', 'Potential viruses infection', 'Bad', 5);
INSERT INTO public."Resource Information" VALUES (30, 'A2123', '2018-07-11', 'Access Facebook', 'Spend too much time on Social Media Facebook', 'Bad', 3);
INSERT INTO public."Resource Information" VALUES (32, 'A2123', '2018-07-28', 'Access Facebook', 'Spend too much time on Social Media Facebook', 'Bad', 3);
INSERT INTO public."Resource Information" VALUES (31, 'A2123', '2018-08-11', 'Access Facebook', 'Spend too much time on Social Media Facebook', 'Bad', 3);
INSERT INTO public."Resource Information" VALUES (3, 'A1234', '2018-01-30', 'Access Facebook', 'Spend too much time on Social Media', 'Bad', 4);
INSERT INTO public."Resource Information" VALUES (5, 'A1234', '2018-02-22', 'Access illegal website download drivers', 'Potential of vulnerabilities', 'Bad', 3);
INSERT INTO public."Resource Information" VALUES (4, 'A1234', '2018-02-10', 'Access Jobstreet', 'Access competitive disadvantages website', 'Bad', 2);
INSERT INTO public."Resource Information" VALUES (6, 'A1234', '2018-01-10', 'Access Facebook

', 'Spend too much time on Social Media', 'Bad', 3);
INSERT INTO public."Resource Information" VALUES (15, 'A1234', '2018-03-29', 'Access sensitive politics website', 'Employee should not access politics content during working hour', 'Bad', 2);
INSERT INTO public."Resource Information" VALUES (16, 'A1234', '2018-05-05', 'Access illegal website to read technologies content', 'Potential viruses infection', 'Bad', 1);
INSERT INTO public."Resource Information" VALUES (17, 'A1234', '2018-05-09', 'Access Twitter', 'Spend too much time on social media application', 'Bad', 2);
INSERT INTO public."Resource Information" VALUES (18, 'A1234', '2018-07-21', 'Access Facebook', 'Spend too much time on social media application', 'Bad', 2);
INSERT INTO public."Resource Information" VALUES (19, 'A1234', '2018-09-06', 'Access unofficial website download licensing software', 'Potential viruses infection', 'Bad', 2);
INSERT INTO public."Resource Information" VALUES (20, 'A1234', '2018-10-01', 'Access unofficial website download cracked software', 'Potential viruses infection', 'Bad', 1);
INSERT INTO public."Resource Information" VALUES (21, 'A1234', '2018-12-02', 'Access Facebook', 'Spend too much time on social media application', 'Bad', 3);
INSERT INTO public."Resource Information" VALUES (22, 'A1234', '2018-12-18', 'Using social media Watsapp application', 'Illegal/Non-compliance chatting application', 'Bad', 3);
INSERT INTO public."Resource Information" VALUES (1, 'A2123', '2018-01-12', 'Surf news', 'Surf news during working hour', 'Bad', 3);
INSERT INTO public."Resource Information" VALUES (2, 'A2123', '2018-01-20', 'Surf news', 'Surf news during working hour', 'Bad', 3);
INSERT INTO public."Resource Information" VALUES (7, 'A2123', '2018-02-22', 'Access unofficial website download application', 'Potential viruses infection', 'Bad', 1);
INSERT INTO public."Resource Information" VALUES (23, 'A2123', '2018-02-26', 'Access unofficial website download application', 'Potential viruses infection', 'Bad', 2);
INSERT INTO public."Resource Information" VALUES (8, 'A2123', '2018-04-07', 'Using social media Watsapp application', 'Illegal/Non-compliance chatting application', 'Bad', 2);
INSERT INTO public."Resource Information" VALUES (24, 'A2123', '2018-04-16', 'Access unofficial website download files', 'Potential viruses infection', 'Bad', 3);
INSERT INTO public."Resource Information" VALUES (9, 'A2123', '2018-06-06', 'Visits non-compliance website to read information', 'Potential viruses infection', 'Bad', 4);
INSERT INTO public."Resource Information" VALUES (10, 'A2123', '2018-08-01', 'Access LinkedIn website', 'Access competitive disadvantages website', 'Bad', 2);
INSERT INTO public."Resource Information" VALUES (11, 'A2123', '2018-09-11', 'Access illegal music download website', 'Potential viruses infection', 'Bad', 2);
INSERT INTO public."Resource Information" VALUES (25, 'A2123', '2018-09-25', 'Accessing and read video from unofficial website', 'Potential viruses infection', 'Bad', 3);
INSERT INTO public."Resource Information" VALUES (12, 'A2123', '2018-11-02', 'Access Facebook', 'Spend too much time on Social Media Facebook', 'Bad', 4);
INSERT INTO public."Resource Information" VALUES (13, 'A2123', '2018-11-28', 'Access Facebook', 'Spend too much time on social media Facebook', 'Bad', 3);
INSERT INTO public."Resource Information" VALUES (14, 'A2123', '2018-12-08', 'Download software from illegal website', 'Potential viruses infection', 'Bad', 2);
INSERT INTO public."Resource Information" VALUES (26, 'A2123', '2018-12-20', 'Access unofficial website download application', 'Potential viruses infection', 'Bad', 3);


--
-- Data for Name: System Settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."System Settings" VALUES (1, '09:00:00', 15, '17:00:00', 15, 1, 1, 3);


--
-- Data for Name: User Profile; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."User Profile" VALUES ('charlie', 'abc123', 'charlie chin');


--
-- Data for Name: Work Delivery Information; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Work Delivery Information" VALUES (4, 'A1234', '2018-01-19', 'Setup 5 new APX Radio stations', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (5, 'A1234', '2018-01-25', 'Troubleshooting SGX Product Issue', 2, 2);
INSERT INTO public."Work Delivery Information" VALUES (6, 'A1234', '2018-02-08', 'Upgrade total 30 RBT Board stations test firmware', 3, 3);
INSERT INTO public."Work Delivery Information" VALUES (7, 'A1234', '2018-02-14', 'Coordinate with IT team on new wireless test for APX Board Programming', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (1, 'A2123', '2018-01-03', 'Upgrade total factory Zebra printer firmware', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (2, 'A2123', '2018-01-16', 'Reformat 5 units Desktop PC for new APX line', 1, 2);
INSERT INTO public."Work Delivery Information" VALUES (3, 'A2123', '2018-02-10', 'Configure Cisco Switch for New APX line', 2, 3);
INSERT INTO public."Work Delivery Information" VALUES (8, 'A2123', '2018-02-19', 'Install wireless network and configure IP for new Toki stations', 1, 3);
INSERT INTO public."Work Delivery Information" VALUES (9, 'A2123', '2018-03-07', 'Install and setup 2 units Windows Server 2012 for new security system', 3, 3);
INSERT INTO public."Work Delivery Information" VALUES (10, 'A2123', '2018-03-25', 'Configure IIS settings for APX product new web applications.', 2, 2);
INSERT INTO public."Work Delivery Information" VALUES (11, 'A2123', '2018-04-02', 'Migrate 3 Physical Servers to VM (Phase 1)', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (12, 'A2123', '2018-04-11', 'Perform firewall rules clean up', 3, 1);
INSERT INTO public."Work Delivery Information" VALUES (13, 'A2123', '2018-05-03', 'Migrate 3 Physical Servers to VM (Phase 2)', 3, 3);
INSERT INTO public."Work Delivery Information" VALUES (14, 'A2123', '2018-05-21', 'Work together Engineering team on new Tetra station IT requirements', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (15, 'A2123', '2018-06-03', 'Perform maintenance on Servers VEEAM backup application', 3, 3);
INSERT INTO public."Work Delivery Information" VALUES (16, 'A2123', '2018-06-21', 'Migrate Server Disaster Recovery to cloud base (Phase 1)', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (17, 'A2123', '2018-07-07', 'Upgrade Windows Server 2008 servers to Windows Server 2012 (Phase 1)', 3, 3);
INSERT INTO public."Work Delivery Information" VALUES (18, 'A2123', '2018-07-10', 'Migrate Server Disaster Recovery to cloud base (Phase 2)', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (19, 'A2123', '2018-08-02', 'Upgrade Windows Server 2008 servers to Windows Server 2012 (Phase 2)', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (20, 'A2123', '2018-08-23', 'Upgrade new firmware for total factory Cisco switch', 3, 3);
INSERT INTO public."Work Delivery Information" VALUES (21, 'A2123', '2018-09-11', 'Upgrade Windows Server 2008 servers to Windows Server 2012 (Phase 3)', 3, 3);
INSERT INTO public."Work Delivery Information" VALUES (22, 'A2123', '2018-09-19', 'Install new Server usage monitoring system', 2, 2);
INSERT INTO public."Work Delivery Information" VALUES (23, 'A2123', '2018-10-05', 'Do documentation and diagram for factory network infrastructure', 1, 2);
INSERT INTO public."Work Delivery Information" VALUES (24, 'A2123', '2018-10-20', 'Upgrade factory Windows Servers Antivirus version', 2, 3);
INSERT INTO public."Work Delivery Information" VALUES (25, 'A2123', '2018-11-01', 'Work together Engineering team to develop new Tahiti product IT system', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (26, 'A2123', '2018-11-17', 'Purchase and add on disk drive to Servers SAN storage', 2, 2);
INSERT INTO public."Work Delivery Information" VALUES (27, 'A2123', '2018-12-10', 'Perform network security enhancement for factory network infrastructure', 3, 1);
INSERT INTO public."Work Delivery Information" VALUES (28, 'A2123', '2018-12-20', 'Upgrade or maintenance on Servers during year end holiday', 3, 3);
INSERT INTO public."Work Delivery Information" VALUES (30, 'A1234', '2018-03-03', 'To implement new firmware for Morpheus Aircheck product', 3, 3);
INSERT INTO public."Work Delivery Information" VALUES (31, 'A1234', '2018-03-14', 'To improve APX Button test stage test time duration', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (32, 'A1234', '2018-04-07', 'To test out new Daytona flashing product', 1, 2);
INSERT INTO public."Work Delivery Information" VALUES (33, 'A1234', '2018-04-18', 'To add on new function for all factory packing stage station', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (34, 'A1234', '2018-05-10', 'Documentation for setup new function for all factory packing stage station', 2, 3);
INSERT INTO public."Work Delivery Information" VALUES (35, 'A1234', '2018-05-22', 'To debug and fix Paradise Compro test slowness issue', 3, 1);
INSERT INTO public."Work Delivery Information" VALUES (36, 'A1234', '2018-06-02', 'Upgrade Tetra Aragorn Tunetest software version', 2, 3);
INSERT INTO public."Work Delivery Information" VALUES (37, 'A1234', '2018-06-14', 'Setup and release Hawaii new product line (Phase 1)', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (38, 'A1234', '2018-07-07', 'Setup and release Hawaii new product line (Phase 2)', 3, 3);
INSERT INTO public."Work Delivery Information" VALUES (39, 'A1234', '2018-07-20', 'To modify and improve Battery EOL test sequence', 3, 1);
INSERT INTO public."Work Delivery Information" VALUES (40, 'A1234', '2018-08-04', 'Setup and release Hawaii new product line (Phase 3)', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (41, 'A1234', '2018-08-23', 'To debug and fix O2O4 board programming high failure issue', 2, 3);
INSERT INTO public."Work Delivery Information" VALUES (42, 'A1234', '2018-09-06', 'Setup and release Hawaii new product line (Phase 4 - Final stage)', 2, 3);
INSERT INTO public."Work Delivery Information" VALUES (43, 'A1234', '2018-09-14', 'Add on new test sequence requirement for APX functional test station', 2, 3);
INSERT INTO public."Work Delivery Information" VALUES (44, 'A1234', '2018-10-10', 'Verify and generate the report for total factory test station', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (45, 'A1234', '2018-10-18', 'To test out pilot run for APX radio test new board firmware', 3, 3);
INSERT INTO public."Work Delivery Information" VALUES (46, 'A1234', '2018-11-09', 'To test out new MTP software to replace current PCPats software', 3, 2);
INSERT INTO public."Work Delivery Information" VALUES (47, 'A1234', '2018-11-20', 'Add on new require code for Paradise Board flashing stage', 2, 3);
INSERT INTO public."Work Delivery Information" VALUES (48, 'A1234', '2018-12-04', 'Debug and fix high power failure for Fusion Leak test', 3, 1);
INSERT INTO public."Work Delivery Information" VALUES (49, 'A1234', '2018-12-12', 'To install new test terminal for Solomon Label Print station', 1, 3);


--
-- Name: Attendance Information_Attendance ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Attendance Information_Attendance ID_seq"', 111, true);


--
-- Name: Performance Review_Review ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Performance Review_Review ID_seq"', 29, true);


--
-- Name: Resource Information_Resource ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Resource Information_Resource ID_seq"', 32, true);


--
-- Name: System Settings_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."System Settings_ID_seq"', 1, true);


--
-- Name: Work Delivery Information_Work Delivery ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Work Delivery Information_Work Delivery ID_seq"', 49, true);


--
-- Name: Attendance Information Attendance Information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Attendance Information"
    ADD CONSTRAINT "Attendance Information_pkey" PRIMARY KEY ("Attendance ID");


--
-- Name: Employee Profile Employee Profile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee Profile"
    ADD CONSTRAINT "Employee Profile_pkey" PRIMARY KEY ("Employee ID");


--
-- Name: Performance Review Performance Review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Performance Review"
    ADD CONSTRAINT "Performance Review_pkey" PRIMARY KEY ("Review ID");


--
-- Name: Resource Information Resource Information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Resource Information"
    ADD CONSTRAINT "Resource Information_pkey" PRIMARY KEY ("Resource ID");


--
-- Name: System Settings System Settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."System Settings"
    ADD CONSTRAINT "System Settings_pkey" PRIMARY KEY ("ID");


--
-- Name: User Profile User Profile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User Profile"
    ADD CONSTRAINT "User Profile_pkey" PRIMARY KEY ("Username");


--
-- Name: Work Delivery Information Work Delivery Information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Work Delivery Information"
    ADD CONSTRAINT "Work Delivery Information_pkey" PRIMARY KEY ("Work Delivery ID");


--
-- PostgreSQL database dump complete
--

