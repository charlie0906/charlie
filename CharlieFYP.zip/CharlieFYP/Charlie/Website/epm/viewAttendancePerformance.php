<?php
	if ( !isset ( $_POST['attendanceEmployeeID'] ) || !isset ( $_POST['attendanceYearMonth'] ) )
		header ( 'Location:employeePerformanceRetrieval.php' );

	require ( 'header.php' );

	$employeeID = $_POST['attendanceEmployeeID'];
	$yearMonth = $_POST['attendanceYearMonth'];
	
	$yearMonthFields = explode ( '-', $yearMonth );
	$year = $yearMonthFields [ 0 ];
	
	switch ( $yearMonthFields [ 1 ] )
	{
		case '01': $month = 'January'; break;
		case '02': $month = 'February'; break;
		case '03': $month = 'March'; break;
		case '04': $month = 'April'; break;
		case '05': $month = 'May'; break;
		case '06': $month = 'June'; break;
		case '07': $month = 'July'; break;
		case '08': $month = 'August'; break;
		case '09': $month = 'September'; break;
		case '10': $month = 'Oectober'; break;
		case '11': $month = 'November'; break;
		case '12': $month = 'December'; break;
	}
?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
<h3>Attendance Performance for <?php echo $employeeID; ?> for <?php echo "$month $year"; ?></h3>
<table width='90%' border='1'>
<tr>
	<th>No</th>
    <th>Date</th>
    <th>In</th>
    <th>Out</th>
    <th>Remarks</th>
    <th>Status</th>
</tr>
<?php
	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "In Time","In Tolerance","Out Time","Out Tolerance" FROM "System Settings" ORDER BY "ID" DESC LIMIT 1' );

	$inTime = ReadField ( $result, 0, 'In Time' );
	$inTolerance = ReadField ( $result, 0, 'In Tolerance' );
	$outTime = ReadField ( $result, 0, 'Out Time' );
	$outTolerance = ReadField ( $result, 0, 'Out Tolerance' );

	$result = QueryDatabase ( $connection, 'SELECT to_char("Date",\'FMDD/FMMM/YYYY\') AS "Performance Date",to_char("In",\'FMHH12:MI pm\') AS "Performance In",to_char("Out",\'FMHH12:MI pm\') AS "Performance Out","Remarks",to_char("In"-' . "'$inTime'" . ',\'FMHH24:FMMI\') AS "In Difference",to_char(' . "'$outTime'" . '-"Out",\'FMHH24:FMMI\') AS "Out Difference","Status" FROM "Attendance Information" WHERE to_char("Date",\'YYYY-MM\')=' . "'$yearMonth' AND \"Employee ID\"='$employeeID' ORDER BY \"Date\" ASC,\"In\" ASC" );

	$numItems = GetNumRows ( $result );

	$goodCount = 0;
	$badCount = 0;

	for ( $itemIndex = 0; $itemIndex < $numItems; ++$itemIndex )
	{
		$no = $itemIndex + 1;
		$date = ReadField ( $result, $itemIndex, 'Performance Date' );
		$in = ReadField ( $result, $itemIndex, 'Performance In' );
		$out = ReadField ( $result, $itemIndex, 'Performance Out' );
		$remarks = ReadField ( $result, $itemIndex, 'Remarks' );

		$inDifferenceFields = explode ( ':', ReadField ( $result, $itemIndex, 'In Difference' ) );
		$outDifferenceFields = explode ( ':', ReadField ( $result, $itemIndex, 'Out Difference' ) );

		$inDifference = $inDifferenceFields [ 0 ] * 60 + $inDifferenceFields [ 1 ];
		$outDifference = $outDifferenceFields [ 0 ] * 60 + $outDifferenceFields [ 1 ];

		$status = ReadField ( $result, $itemIndex, 'Status' );

		if ( $inDifference > $inTolerance || $outDifference > $outTolerance )
		{
			if ( $status !== 'Good' )
				++$badCount;
			else
				++$goodCount;
		}
		else
			++$goodCount;

		echo "<tr align='center' valign='top'>\n";
		echo "    <td>$no</td>\n";
		echo "    <td>$date</td>\n";
		echo "    <td>$in</td>\n";
		echo "    <td>$out</td>\n";
		echo "    <td>$remarks</td>\n";
		echo "    <td>$status</td>\n";
		echo "</tr>\n";
	}

	CloseDatabase ( $connection );

	if ( $numItems > 0 )
	{
		$totalCount = $goodCount + $badCount;
		$result = ( $totalCount - $badCount ) / $totalCount * 100;
	}
?>
</table><br /><br />
<form onsubmit='return SavePerformance()'>
<table width='90%'>
<tr>
	<td width='18%'>Attendance Performance Formula:</td>
    <td width='22%'><select id='performanceFormula' class='textInputs' required='required'>
    <option value='Standard'>Standard</option>
    </select></td>
    <td width='60%'>&nbsp;</td>
</tr>
<tr>
	<td colspan='3'><br /></td>
</tr>
<tr>
	<td>Result:</td>
    <td><?php echo ( $numItems > 0 ) ? number_format ( $result, 0 ) . ' %' : '---'; ?></td>
</tr>
<tr>
	<td colspan='3'><br /></td>
</tr>
<tr>
	<td colspan='3'><input type='submit' value='Save' class='buttons' style='width:200px;height:50px' />&nbsp;<input type='button' value='Back' class='buttons' style='width:200px;height:50px' onclick='history.go(-1)' /></td>
</tr>
<?php require ( 'footer.php' ); ?>