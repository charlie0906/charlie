<?php
	if ( !isset ( $_POST['workDeliveryEmployeeID'] ) || !isset ( $_POST['workDeliveryYearMonth'] ) )
		header ( 'Location:employeePerformanceRetrieval.php' );

	require ( 'header.php' );

	$employeeID = $_POST['workDeliveryEmployeeID'];
	$yearMonth = $_POST['workDeliveryYearMonth'];
	
	$yearMonthFields = explode ( '-', $yearMonth );
	$year = $yearMonthFields [ 0 ];
	
	switch ( $yearMonthFields [ 1 ] )
	{
		case '01': $month = 'January'; break;
		case '02': $month = 'February'; break;
		case '03': $month = 'March'; break;
		case '04': $month = 'April'; break;
		case '05': $month = 'May'; break;
		case '06': $month = 'June'; break;
		case '07': $month = 'July'; break;
		case '08': $month = 'August'; break;
		case '09': $month = 'September'; break;
		case '10': $month = 'Oectober'; break;
		case '11': $month = 'November'; break;
		case '12': $month = 'December'; break;
	}
?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
<h3>Work Delivery Performance for <?php echo $employeeID; ?> for <?php echo "$month $year"; ?></h3>
<table width='90%' border='1'>
<tr>
	<th>No</th>
    <th>Date</th>
    <th>Activity/Task</th>
    <th>Difficulty</th>
    <th>Performance</th>
</tr>
<?php
	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "Maximum Performance" FROM "System Settings" ORDER BY "ID" DESC LIMIT 1' );

	$maximumPerformance = ReadField ( $result, 0, 'Maximum Performance' );

	$result = QueryDatabase ( $connection, 'SELECT to_char("Date",\'FMDD/FMMM/YYYY\') AS "Performance Date","Activity/Task","Difficulty","Performance" FROM "Work Delivery Information" WHERE to_char("Date",\'YYYY-MM\')=' . "'$yearMonth' AND \"Employee ID\"='$employeeID' ORDER BY \"Date\" ASC" );

	$numItems = GetNumRows ( $result );

	$score = 0;
	$perfectScore = 0;

	for ( $itemIndex = 0; $itemIndex < $numItems; ++$itemIndex )
	{
		$no = $itemIndex + 1;
		$date = ReadField ( $result, $itemIndex, 'Performance Date' );
		$activityTask = ReadField ( $result, $itemIndex, 'Activity/Task' );
		$difficulty = ReadField ( $result, $itemIndex, 'Difficulty' );
		$performance = ReadField ( $result, $itemIndex, 'Performance' );

		$score += $difficulty * $performance;
		$perfectScore += $difficulty * $maximumPerformance;

		echo "<tr align='center' valign='top'>\n";
		echo "    <td>$no</td>\n";
		echo "    <td>$date</td>\n";
		echo "    <td>$activityTask</td>\n";
		echo "    <td>$difficulty</td>\n";
		echo "    <td>$performance</td>\n";
		echo "</tr>\n";
	}

	CloseDatabase ( $connection );

	if ( $numItems > 0 )
		$result = $score / $perfectScore * 100;
?>
</table><br /><br />
<form onsubmit='return SavePerformance()'>
<table width='90%'>
<tr>
	<td width='18%'>Work Delivery Formula:</td>
    <td width='22%'><select id='performanceFormula' class='textInputs' required='required'>
    <option value='Standard'>Standard</option>
    </select></td>
    <td width='60%'>&nbsp;</td>
</tr>
<tr>
	<td colspan='3'><br /></td>
</tr>
<tr>
	<td>Result:</td>
    <td><?php echo ( $numItems > 0 ) ? number_format ( $result, 0 ) . ' %' : '---'; ?></td>
</tr>
<tr>
	<td colspan='3'><br /></td>
</tr>
<tr>
	<td colspan='3'><input type='submit' value='Save' class='buttons' style='width:200px;height:50px' />&nbsp;<input type='button' value='Back' class='buttons' style='width:200px;height:50px' onclick='history.go(-1)' /></td>
</tr>
<?php require ( 'footer.php' ); ?>