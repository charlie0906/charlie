<?php require ( 'header.php' ); ?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
<script type='text/javascript'>
var performanceType

function ViewAttendancePerformance()
{
	performanceType = 1
	document.getElementById('btnSubmit').click()
}

function ViewResourcePerformance()
{
	performanceType = 2
	document.getElementById('btnSubmit').click()
}

function ViewWorkDeliveryPerformance()
{
	performanceType = 3
	document.getElementById('btnSubmit').click()
}

function ViewFinalPerformance()
{
	performanceType = 4
	document.getElementById('btnSubmit').click()
}

function ViewFinalPerformanceByYear()
{
	performanceType = 5
	document.getElementById('btnSubmit').click()
}

function ViewPerformance()
{
	var employeeIDEl = document.getElementById('employeeID')
	var employeeID = employeeIDEl.options [ employeeIDEl.selectedIndex ].value

	var monthEl = document.getElementById('month')
	var month = monthEl.options [ monthEl.selectedIndex ].value

	var yearEl = document.getElementById('year')
	var year = yearEl.options [ yearEl.selectedIndex ].value

	var yearMonth = '' + year + '-' + month

	switch ( performanceType )
	{
		case 1:
			document.getElementById('attendanceEmployeeID').value = employeeID
			document.getElementById('attendanceYearMonth').value = yearMonth
			document.getElementById('frmAttendance').submit()
			break

		case 2:
			document.getElementById('resourceEmployeeID').value = employeeID
			document.getElementById('resourceYearMonth').value = yearMonth
			document.getElementById('frmResource').submit()
			break

		case 3:
			document.getElementById('workDeliveryEmployeeID').value = employeeID
			document.getElementById('workDeliveryYearMonth').value = yearMonth
			document.getElementById('frmWorkDelivery').submit()
			break

		case 4:
			document.getElementById('finalEmployeeID').value = employeeID
			document.getElementById('finalYearMonth').value = yearMonth
			document.getElementById('frmFinal').submit()
			break

		case 5:
			document.getElementById('finalEmployeeIDByYear').value = employeeID
			document.getElementById('finalYear').value = year
			document.getElementById('frmFinalByYear').submit()
			break
	}

	return false
}
</script>
<h3>Employee Performance Input Retrieval</h3><br />
<form id='frmPerformance' onsubmit='return ViewPerformance()'>
<table width='40%'>
<tr>
	<td width='40%'>Employee ID:</td>
    <td width='60%'><select id='employeeID' class='textInputs' required='required'>
    <?php
		require_once ( 'database.php' );

		$connection = OpenDatabase();

		$result = QueryDatabase ( $connection, 'SELECT "Employee ID","Name" FROM "Employee Profile" ORDER BY "Employee ID" ASC' );

		$numEmployees = GetNumRows ( $result );

		for ( $employeeIndex = 0; $employeeIndex < $numEmployees; ++$employeeIndex )
		{
			$employeeID = ReadField ( $result, $employeeIndex, 'Employee ID' );
			$employeeName = ReadField ( $result, $employeeIndex, 'Name' );

			echo "    <option value='$employeeID'>$employeeID ($employeeName)</option>\n";
		}

		CloseDatabase ( $connection );
	?>
    </select></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Month:</td>
    <td><select id='month' class='textInputs' required='required'>
    <option value='01'>January</option>
    <option value='02'>February</option>
    <option value='03'>March</option>
    <option value='04'>April</option>
    <option value='05'>May</option>
    <option value='06'>June</option>
    <option value='07'>July</option>
    <option value='08'>August</option>
    <option value='09'>September</option>
    <option value='10'>October</option>
    <option value='11'>November</option>
    <option value='12'>December</option>
    </select></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Year:</td>
    <td><select id='year' class='textInputs' required='required'>
    <?php
		for ( $year = 2015; $year <= 2025; ++$year )
		{
			if ( $year != 2019 )
				echo "    <option value='$year'>$year</option>\n";
			else
				echo "    <option value='$year' selected='selected'>$year</option>\n";
		}
	?>
    </select></td>
</tr>
<tr>
	<td colspan='2'><br /><input type='button' value='View Attendance Performance' class='buttons' style='width:100%' onclick='ViewAttendancePerformance()' /><br />
<br /><input type='button' value='View Resource Performance' class='buttons' style='width:100%' onclick='ViewResourcePerformance()' /><br />
<br /><input type='button' value='View Work Delivery Performance' class='buttons' style='width:100%' onclick='ViewWorkDeliveryPerformance()' /><br />
<br /><input type='button' value='View Final Performance By Month' class='buttons' style='width:100%' onclick='ViewFinalPerformance()' /><br />
<br /><input type='button' value='View Final Performance By Year' class='buttons' style='width:100%' onclick='ViewFinalPerformanceByYear()' /><br />
<br /><br /><br /><br /><input type='button' value='Back' class='buttons' onclick='history.go(-1)' /><input type='submit' id='btnSubmit' style='visibility:hidden;position:absolute' /></td>
</tr>
</table>
</form>
<form id='frmAttendance' method='post' action='viewAttendancePerformance.php'>
<input type='hidden' id='attendanceEmployeeID' name='attendanceEmployeeID' />
<input type='hidden' id='attendanceYearMonth' name='attendanceYearMonth' />
</form>
<form id='frmResource' method='post' action='viewResourcePerformance.php'>
<input type='hidden' id='resourceEmployeeID' name='resourceEmployeeID' />
<input type='hidden' id='resourceYearMonth' name='resourceYearMonth' />
</form>
<form id='frmWorkDelivery' method='post' action='viewWorkDeliveryPerformance.php'>
<input type='hidden' id='workDeliveryEmployeeID' name='workDeliveryEmployeeID' />
<input type='hidden' id='workDeliveryYearMonth' name='workDeliveryYearMonth' />
</form>
<form id='frmFinal' method='post' action='viewFinalPerformance.php'>
<input type='hidden' id='finalEmployeeID' name='finalEmployeeID' />
<input type='hidden' id='finalYearMonth' name='finalYearMonth' />
</form>
<form id='frmFinalByYear' method='post' action='viewFinalPerformanceByYear.php'>
<input type='hidden' id='finalEmployeeIDByYear' name='finalEmployeeIDByYear' />
<input type='hidden' id='finalYear' name='finalYear' />
</form>
<?php require ( 'footer.php' ); ?>