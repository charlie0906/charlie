<?php
	$employeeID = $_POST['employeeID'];

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT COUNT(*) AS "Exist Count" FROM "Employee Profile" WHERE "Employee ID"=' . "'$employeeID'" );

	if ( ReadField ( $result, 0, 'Exist Count' ) != 1 )
	{
		CloseDatabase ( $connection );
		die ( 'Not Found' );
	}

	QueryDatabase ( $connection, 'DELETE FROM "Employee Profile" WHERE "Employee ID"=' . "'$employeeID'" );

	CloseDatabase ( $connection );

	die ( 'Success' );
?>
