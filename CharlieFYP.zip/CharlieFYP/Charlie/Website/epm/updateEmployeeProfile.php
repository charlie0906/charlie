<?php
	if ( !isset ( $_GET['employeeID'] ) )
		header ( 'Location:createEmployeeProfile.php' );

	require ( 'header.php' );

	$employeeID = $_GET['employeeID'];

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "Name","Date of Birth","Gender","Position","Department","Direct Manager" FROM "Employee Profile" WHERE "Employee ID"=' . "'$employeeID'" );

	$employeeName = ReadField ( $result, 0, 'Name' );
	$employeeDOB = ReadField ( $result, 0, 'Date of Birth' );
	$employeeGender = ReadField ( $result, 0, 'Gender' );
	$employeePosition = ReadField ( $result, 0, 'Position' );
	$employeeDepartment = ReadField ( $result, 0, 'Department' );
	$employeeDirectManager = ReadField ( $result, 0, 'Direct Manager' );

	CloseDatabase ( $connection );
?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
<script type='text/javascript'>
function UpdateEmployeeProfile()
{
	var employeeName = document.getElementById('name').value
	var dob = document.getElementById('dob').value

	var genderEl = document.getElementById('gender')
	var gender = genderEl.options [ genderEl.selectedIndex ].value

	var position = document.getElementById('position').value
	var department = document.getElementById('department').value
	var directManager = document.getElementById('directManager').value

	position = position.replace ( '&', '~~' )
	position = position.replace ( '=', '``' )

	department = department.replace ( '&', '~~' )
	department = department.replace ( '=', '``' )

	directManager = directManager.replace ( '&', '~~' )
	directManager = directManager.replace ( '=', '``' )

	// AJAX codes
	if ( window.XMLHttpRequest )
	{
		// code for modern browsers
		xmlhttp = new XMLHttpRequest()
	}
	else
	{
		// code for old IE browsers
		xmlhttp = new ActiveXObject ( 'Microsoft.XMLHTTP' )
	}

    xmlhttp.onreadystatechange = function()
	{
        if ( this.readyState == 4 && this.status == 200 )
		{
			if ( this.responseText === 'Success' )
			{
				alert ( 'Employee profile updated in database successfully!' )
				location.reload ( true )
			}
			else if ( this.responseText === 'Not Found' )
			    alert ( 'Employee ID not found in database!' )
			else
				alert ( this.responseText )
        }
    }

    xmlhttp.open ( 'POST', 'ajax_updateEmployeeProfile.php', true )
    xmlhttp.setRequestHeader ( 'Content-type', 'application/x-www-form-urlencoded' )
    xmlhttp.send ( 'employeeID=<?php echo $employeeID; ?>&name=' + employeeName + '&dob=' + dob + '&gender=' + gender + '&position=' + position + '&department=' + department + '&directManager=' + directManager )

	return false
}
</script>
<h3>Update Employee Profile</h3><br />
<form onsubmit='return UpdateEmployeeProfile()'>
<table width='50%'>
<tr>
	<td width='40%'>Employee ID:</td>
    <td width='60%'><?php echo $employeeID; ?></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Name:</td>
    <td><input type='text' id='name' value='<?php echo $employeeName; ?>' class='textInputs' required='required' /></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Date of Birth:</td>
    <td><input type='date' id='dob' value='<?php echo $employeeDOB; ?>' class='textInputs' required='required' /></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Gender:</td>
    <td><select id='gender' class='textInputs' required='required'>
    <option value=''>Select gender...</option>
    <option value='Male'<?php if ( $employeeGender === 'Male' ) echo " selected='selected'"; ?>>Male</option>
    <option value='Female'<?php if ( $employeeGender === 'Female' ) echo " selected='selected'"; ?>>Female</option>
    </select></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Position:</td>
    <td><input type='text' id='position' value='<?php echo $employeePosition; ?>' class='textInputs' required='required' /></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Department:</td>
    <td><input type='text' id='department' value='<?php echo $employeeDepartment; ?>' class='textInputs' required='required' /></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Direct Manager:</td>
    <td><input type='text' id='directManager' value='<?php echo $employeeDirectManager; ?>' class='textInputs' required='required' /></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td colspan='2'><input type='submit' value='Update' class='buttons' style='width:200px;height:50px' />&nbsp;<input type='button' value='Back' class='buttons' style='width:200px;height:50px' onclick='history.go(-1)' /></td>
</tr>
</table>
</form>
<?php require ( 'footer.php' ); ?>