<?php
	$employeeID = $_POST['employeeID'];
	$name = $_POST['name'];
	$dob = $_POST['dob'];
	$gender = $_POST['gender'];
	$position = $_POST['position'];
	$department = $_POST['department'];
	$directManager = $_POST['directManager'];

	$position = str_replace ( '~~', '&', $position );
	$position = str_replace ( '``', '=', $position );
	$position = str_replace ( "'", '`', $position );

	$department = str_replace ( '~~', '&', $department );
	$department = str_replace ( '``', '=', $department );
	$department = str_replace ( "'", '`', $department );

	$directManager = str_replace ( '~~', '&', $directManager );
	$directManager = str_replace ( '``', '=', $directManager );
	$directManager = str_replace ( "'", '`', $directManager );

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT COUNT(*) AS "Duplicate Count" FROM "Employee Profile" WHERE "Employee ID"=' . "'$employeeID'" );

	if ( ReadField ( $result, 0, 'Duplicate Count' ) > 0 )
	{
		CloseDatabase ( $connection );
		die ( 'Duplicate' );
	}

	$sql = 'INSERT INTO "Employee Profile" ("Employee ID","Name","Date of Birth","Gender","Position","Department","Direct Manager") VALUES ' .
		   "('$employeeID','$name','$dob','$gender','$position','$department','$directManager')";

	QueryDatabase ( $connection, $sql );

	CloseDatabase ( $connection );

	die ( 'Success' );
?>
