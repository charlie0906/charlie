<?php require ( 'header.php' ); ?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
<script type='text/javascript'>
function AddNewEmployee()
{
	var employeeID = document.getElementById('employeeID').value
	var employeeName = document.getElementById('name').value
	var dob = document.getElementById('dob').value

	var genderEl = document.getElementById('gender')
	var gender = genderEl.options [ genderEl.selectedIndex ].value

	var position = document.getElementById('position').value
	var department = document.getElementById('department').value
	var directManager = document.getElementById('directManager').value

	position = position.replace ( '&', '~~' )
	position = position.replace ( '=', '``' )

	department = department.replace ( '&', '~~' )
	department = department.replace ( '=', '``' )

	directManager = directManager.replace ( '&', '~~' )
	directManager = directManager.replace ( '=', '``' )

	// AJAX codes
	if ( window.XMLHttpRequest )
	{
		// code for modern browsers
		xmlhttp = new XMLHttpRequest()
	}
	else
	{
		// code for old IE browsers
		xmlhttp = new ActiveXObject ( 'Microsoft.XMLHTTP' )
	}

    xmlhttp.onreadystatechange = function()
	{
        if ( this.readyState == 4 && this.status == 200 )
		{
			if ( this.responseText === 'Success' )
			{
				alert ( 'Employee added to database successfully!' )
				location.reload ( true )
			}
			else if ( this.responseText === 'Duplicate' )
			    alert ( 'Employee ID already exist in database!' )
			else
				alert ( this.responseText )
        }
    }

    xmlhttp.open ( 'POST', 'ajax_addNewEmployee.php', true )
    xmlhttp.setRequestHeader ( 'Content-type', 'application/x-www-form-urlencoded' )
    xmlhttp.send ( 'employeeID=' + employeeID + '&name=' + employeeName + '&dob=' + dob + '&gender=' + gender + '&position=' + position + '&department=' + department + '&directManager=' + directManager )

	return false	
}

function DeleteEmployeeProfile ( employeeID )
{
	// AJAX codes
	if ( window.XMLHttpRequest )
	{
		// code for modern browsers
		xmlhttp = new XMLHttpRequest()
	}
	else
	{
		// code for old IE browsers
		xmlhttp = new ActiveXObject ( 'Microsoft.XMLHTTP' )
	}

    xmlhttp.onreadystatechange = function()
	{
        if ( this.readyState == 4 && this.status == 200 )
		{
			if ( this.responseText === 'Success' )
			{
				alert ( 'Employee deleted from database successfully!' )
				location.reload ( true )
			}
			else if ( this.responseText === 'Not Found' )
			    alert ( 'Employee ID not found in database!' )
			else
				alert ( this.responseText )
        }
    }

    xmlhttp.open ( 'POST', 'ajax_deleteEmployee.php', true )
    xmlhttp.setRequestHeader ( 'Content-type', 'application/x-www-form-urlencoded' )
    xmlhttp.send ( 'employeeID=' + employeeID )
}
</script>
<h3>Employee Profile</h3>
<table width='90%' border='1'>
<tr>
	<th>No</th>
    <th>Employee ID</th>
    <th>Name</th>
    <th>Department</th>
    <th>Action</th>
</tr>
<?php
	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "Employee ID","Name","Department" FROM "Employee Profile" ORDER BY "Employee ID" ASC' );

	$numEmployees = GetNumRows ( $result );

	for ( $employeeIndex = 0; $employeeIndex < $numEmployees; ++$employeeIndex )
	{
		$no = $employeeIndex + 1;
		$employeeID = ReadField ( $result, $employeeIndex, 'Employee ID' );
		$employeeName = ReadField ( $result, $employeeIndex, 'Name' );
		$employeeDepartment = ReadField ( $result, $employeeIndex, 'Department' );

		echo "<tr align='center'>\n";
		echo "    <td>$no</td>\n";
		echo "    <td>$employeeID</td>\n";
		echo "    <td>$employeeName</td>\n";
		echo "    <td>$employeeDepartment</td>\n";
		echo "    <td><input type='button' value='Update' class='buttons' style='width:150px;height:30px' onclick='location.href=\"updateEmployeeProfile.php?employeeID=$employeeID\"' />&nbsp;<input type='button' value='Delete' class='buttons' style='width:150px;height:30px' onclick='DeleteEmployeeProfile(\"$employeeID\")' /></td>\n";
		echo "</tr>\n";
	}

	CloseDatabase ( $connection );
?>
</table><br /><br />
<form onsubmit='return AddNewEmployee()'>
<table width='90%'>
<tr>
	<td width='14%'>Employee ID:</td>
    <td width='26%'><input type='text' id='employeeID' placeholder='Enter employee ID...' class='textInputs' required='required' /></td>
    <td width='60%'>&nbsp;</td>
</tr>
<tr>
	<td colspan='3'><br /></td>
</tr>
<tr>
	<td>Name:</td>
    <td><input type='text' id='name' placeholder='Enter name...' class='textInputs' required='required' /></td>
    <td>&nbsp;</td>
</tr>
<tr>
	<td colspan='3'><br /></td>
</tr>
<tr>
	<td>Date of Birth:</td>
    <td><input type='date' id='dob' placeholder='Enter date of birth...' class='textInputs' required='required' /></td>
    <td>&nbsp;</td>
</tr>
<tr>
	<td colspan='3'><br /></td>
</tr>
<tr>
	<td>Gender:</td>
    <td><select id='gender' class='textInputs' required='required'>
    <option value=''>Select gender...</option>
    <option value='Male'>Male</option>
    <option value='Female'>Female</option>
    </select></td>
    <td>&nbsp;</td>
</tr>
<tr>
	<td colspan='3'><br /></td>
</tr>
<tr>
	<td>Position:</td>
    <td><input type='text' id='position' placeholder='Enter position...' class='textInputs' required='required' /></td>
    <td>&nbsp;</td>
</tr>
<tr>
	<td colspan='3'><br /></td>
</tr>
<tr>
	<td>Department:</td>
    <td><input type='text' id='department' placeholder='Enter department...' class='textInputs' required='required' /></td>
    <td>&nbsp;</td>
</tr>
<tr>
	<td colspan='3'><br /></td>
</tr>
<tr>
	<td>Direct Manager:</td>
    <td><input type='text' id='directManager' placeholder='Enter direct Manager...' class='textInputs' required='required' /></td>
    <td>&nbsp;</td>
</tr>
<tr>
	<td colspan='3'><br /></td>
</tr>
<tr>
	<td colspan='3'><input type='submit' value='Add New Employee' class='buttons' style='width:200px;height:50px' />&nbsp;<input type='reset' value='Clear' class='buttons' style='width:200px;height:50px' />&nbsp;<input type='button' value='Back' class='buttons' style='width:200px;height:50px' onclick='history.go(-1)' /></td>
</tr>
</table>
</form>
<?php require ( 'footer.php' ); ?>