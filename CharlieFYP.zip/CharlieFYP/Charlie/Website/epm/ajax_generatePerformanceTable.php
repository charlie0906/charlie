<table width='90%' border='1'>
<tr>
	<th>No</th>
    <th>Review Date</th>
    <th>Employee ID</th>
    <th>Name</th>
    <th>Attendance Performance</th>
    <th>Resource Usage Performance</th>
    <th>Work Delivery Performance</th>
    <th>Final Performance</th>
</tr>
<?php
	$employeeID = $_POST['employeeID'];
	$year = $_POST['year'];

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	if ( $employeeID !== '' )
	{
		if ( $year !== '' )
		{
			$result = QueryDatabase ( $connection, 'SELECT to_char("Review Date",\'FMMonth YYYY\') AS "ReviewDate","Performance Review"."Employee ID" AS "Employee ID","Name","Attendance Performance","Resource Usage Performance","Work Delivery Performance","Final Performance Index" FROM "Performance Review" INNER JOIN "Employee Profile" ON "Performance Review"."Employee ID"="Employee Profile"."Employee ID" WHERE "Performance Review"."Employee ID"=' . "'$employeeID'" . ' AND to_char("Review Date",\'YYYY\')=' . "'$year'" . ' ORDER BY "Review Date" DESC,"Performance Review"."Employee ID" ASC' );
		}
		else
		{
			$result = QueryDatabase ( $connection, 'SELECT to_char("Review Date",\'FMMonth YYYY\') AS "ReviewDate","Performance Review"."Employee ID" AS "Employee ID","Name","Attendance Performance","Resource Usage Performance","Work Delivery Performance","Final Performance Index" FROM "Performance Review" INNER JOIN "Employee Profile" ON "Performance Review"."Employee ID"="Employee Profile"."Employee ID" WHERE "Performance Review"."Employee ID"=' . "'$employeeID'" . ' ORDER BY "Review Date" DESC,"Performance Review"."Employee ID" ASC' );
		}
	}
	else
	{
		if ( $year !== '' )
		{
			$result = QueryDatabase ( $connection, 'SELECT to_char("Review Date",\'FMMonth YYYY\') AS "ReviewDate","Performance Review"."Employee ID" AS "Employee ID","Name","Attendance Performance","Resource Usage Performance","Work Delivery Performance","Final Performance Index" FROM "Performance Review" INNER JOIN "Employee Profile" ON "Performance Review"."Employee ID"="Employee Profile"."Employee ID" WHERE to_char("Review Date",\'YYYY\')=' . "'$year'" . ' ORDER BY "Review Date" DESC,"Performance Review"."Employee ID" ASC' );
		}
		else
		{
			$result = QueryDatabase ( $connection, 'SELECT to_char("Review Date",\'FMMonth YYYY\') AS "ReviewDate","Performance Review"."Employee ID" AS "Employee ID","Name","Attendance Performance","Resource Usage Performance","Work Delivery Performance","Final Performance Index" FROM "Performance Review" INNER JOIN "Employee Profile" ON "Performance Review"."Employee ID"="Employee Profile"."Employee ID" ORDER BY "Review Date" DESC,"Performance Review"."Employee ID" ASC' );
		}
	}

	$numPerformance = GetNumRows ( $result );

	for ( $performanceIndex = 0; $performanceIndex < $numPerformance; ++$performanceIndex )
	{
		$no = $performanceIndex + 1;
		$reviewDate = ReadField ( $result, $performanceIndex, 'ReviewDate' );
		$employeeID = ReadField ( $result, $performanceIndex, 'Employee ID' );
		$employeeName = ReadField ( $result, $performanceIndex, 'Name' );
		$attendancePerformance = number_format ( ReadField ( $result, $performanceIndex, 'Attendance Performance' ), 0 );
		$resourceUsagePerformance = number_format ( ReadField ( $result, $performanceIndex, 'Resource Usage Performance' ), 0 );
		$workDeliveryPerformance = number_format ( ReadField ( $result, $performanceIndex, 'Work Delivery Performance' ), 0 );
		$finalPerformanceIndex = number_format ( ReadField ( $result, $performanceIndex, 'Final Performance Index' ), 0 );

		echo "<tr align='center'>\n";
		echo "    <td>$no</td>\n";
		echo "    <td>$reviewDate</td>\n";
		echo "    <td>$employeeID</td>\n";
		echo "    <td>$employeeName</td>\n";
		echo "    <td>$attendancePerformance %</td>\n";
		echo "    <td>$resourceUsagePerformance %</td>\n";
		echo "    <td>$workDeliveryPerformance %</td>\n";
		echo "    <td>$finalPerformanceIndex %</td>\n";
		echo "</tr>\n";
	}

	CloseDatabase ( $connection );
?>
</table>