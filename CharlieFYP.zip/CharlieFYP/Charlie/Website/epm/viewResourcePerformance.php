<?php
	if ( !isset ( $_POST['resourceEmployeeID'] ) || !isset ( $_POST['resourceYearMonth'] ) )
		header ( 'Location:employeePerformanceRetrieval.php' );

	require ( 'header.php' );

	$fireHours = 100;

	$employeeID = $_POST['resourceEmployeeID'];
	$yearMonth = $_POST['resourceYearMonth'];
	
	$yearMonthFields = explode ( '-', $yearMonth );
	$year = $yearMonthFields [ 0 ];
	
	switch ( $yearMonthFields [ 1 ] )
	{
		case '01': $month = 'January'; break;
		case '02': $month = 'February'; break;
		case '03': $month = 'March'; break;
		case '04': $month = 'April'; break;
		case '05': $month = 'May'; break;
		case '06': $month = 'June'; break;
		case '07': $month = 'July'; break;
		case '08': $month = 'August'; break;
		case '09': $month = 'September'; break;
		case '10': $month = 'Oectober'; break;
		case '11': $month = 'November'; break;
		case '12': $month = 'December'; break;
	}
?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
<h3>Resource Usage Performance for <?php echo $employeeID; ?> for <?php echo "$month $year"; ?></h3>
<table width='90%' border='1'>
<tr>
	<th>No</th>
    <th>Date</th>
    <th>Detection</th>
    <th>Hours</th>
    <th>Remark</th>
    <th>Status</th>
</tr>
<?php
	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "Detection Tolerance","Weight Per Detection" FROM "System Settings" ORDER BY "ID" DESC LIMIT 1' );

	$detectionTolerance = ReadField ( $result, 0, 'Detection Tolerance' );
	$weightPerDetection = ReadField ( $result, 0, 'Weight Per Detection' );

	$result = QueryDatabase ( $connection, 'SELECT to_char("Date",\'FMDD/FMMM/YYYY\') AS "Performance Date","Detection","Hours","Remark","Status" FROM "Resource Information" WHERE to_char("Date",\'YYYY-MM\')=' . "'$yearMonth' AND \"Employee ID\"='$employeeID' ORDER BY \"Date\" ASC" );

	$numItems = GetNumRows ( $result );

	$surfHours = 0;

	for ( $itemIndex = 0; $itemIndex < $numItems; ++$itemIndex )
	{
		$no = $itemIndex + 1;
		$date = ReadField ( $result, $itemIndex, 'Performance Date' );
		$detection = ReadField ( $result, $itemIndex, 'Detection' );
		$hours = ReadField ( $result, $itemIndex, 'Hours' );
		$remark = ReadField ( $result, $itemIndex, 'Remark' );
		$status = ReadField ( $result, $itemIndex, 'Status' );

		$surfHours += $hours;

		echo "<tr align='center' valign='top'>\n";
		echo "    <td>$no</td>\n";
		echo "    <td>$date</td>\n";
		echo "    <td>$detection</td>\n";
		echo "    <td>$hours</td>\n";
		echo "    <td>$remark</td>\n";
		echo "    <td>$status</td>\n";
		echo "</tr>\n";
	}

	CloseDatabase ( $connection );

	$badSurfHours = $surfHours * $weightPerDetection - $detectionTolerance;

	if ( $numItems > 0 )
	{
		if ( $badSurfHours <= 0 )
			$result = 100;
		else
			$result = ( $fireHours - $badSurfHours ) / $fireHours * 100;
	}
?>
</table><br /><br />
<form onsubmit='return SavePerformance()'>
<table width='90%'>
<tr>
	<td width='18%'>Resource Usage Formula:</td>
    <td width='22%'><select id='performanceFormula' class='textInputs' required='required'>
    <option value='Standard'>Standard</option>
    </select></td>
    <td width='60%'>&nbsp;</td>
</tr>
<tr>
	<td colspan='3'><br /></td>
</tr>
<tr>
	<td>Result:</td>
    <td><?php echo ( $numItems > 0 ) ? number_format ( $result, 0 ) . ' %' : '---'; ?></td>
</tr>
<tr>
	<td colspan='3'><br /></td>
</tr>
<tr>
	<td colspan='3'><input type='submit' value='Save' class='buttons' style='width:200px;height:50px' />&nbsp;<input type='button' value='Back' class='buttons' style='width:200px;height:50px' onclick='history.go(-1)' /></td>
</tr>
<?php require ( 'footer.php' ); ?>