<?php
	$inTime = $_POST['inTime'];
	$inTolerance = $_POST['inTolerance'];
	$outTime = $_POST['outTime'];
	$outTolerance = $_POST['outTolerance'];
	$detectionTolerance = $_POST['detectionTolerance'];
	$weightPerDetection = $_POST['weightPerDetection'];
	$maximumPerformance = $_POST['maximumPerformance'];

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$sql = "UPDATE \"System Settings\" SET \"In Time\"='$inTime',\"In Tolerance\"=$inTolerance,\"Out Time\"='$outTime',\"Out Tolerance\"=$outTolerance,\"Detection Tolerance\"=$detectionTolerance,\"Weight Per Detection\"=$weightPerDetection,\"Maximum Performance\"=$maximumPerformance";

	QueryDatabase ( $connection, $sql );

	CloseDatabase ( $connection );

	die ( 'Success' );
?>
