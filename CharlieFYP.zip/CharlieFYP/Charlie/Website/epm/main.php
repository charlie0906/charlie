<?php require ( 'header.php' ); ?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
<br /><input type='button' value='Create Employee Profile' class='buttons' onclick='location.href="createEmployeeProfile.php"' /><br />
<br /><input type='button' value='Employee Performance Input Retrieval' class='buttons' onclick='location.href="employeePerformanceRetrieval.php"' /><br />
<br /><input type='button' value='System Setting' class='buttons' onclick='location.href="systemSetting.php"' /><br />
<br /><input type='button' value='View Employee Performance' class='buttons' onclick='location.href="viewEmployeePerformance.php"' /><br />
<br /><br /><br /><br /><input type='button' value='Logout' class='buttons' onclick='location.href="logout.php"' />
<?php require ( 'footer.php' ); ?>