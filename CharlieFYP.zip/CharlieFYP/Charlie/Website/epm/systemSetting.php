<?php
	require ( 'header.php' );

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "In Time","In Tolerance","Out Time","Out Tolerance","Detection Tolerance","Weight Per Detection","Maximum Performance" FROM "System Settings" ORDER BY "ID" DESC LIMIT 1' );

	$inTime = ReadField ( $result, 0, 'In Time' );
	$inTolerance = ReadField ( $result, 0, 'In Tolerance' );
	$outTime = ReadField ( $result, 0, 'Out Time' );
	$outTolerance = ReadField ( $result, 0, 'Out Tolerance' );
	$detectionTolerance = ReadField ( $result, 0, 'Detection Tolerance' );
	$weightPerDetection = ReadField ( $result, 0, 'Weight Per Detection' );
	$maximumPerformance = ReadField ( $result, 0, 'Maximum Performance' );

	CloseDatabase ( $connection );
?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
<script type='text/javascript'>
function SaveSettings()
{
	var inTime = document.getElementById('inTime').value
	var inTolerance = document.getElementById('inTolerance').value
	var outTime = document.getElementById('outTime').value
	var outTolerance = document.getElementById('outTolerance').value
	var detectionTolerance = document.getElementById('detectionTolerance').value
	var weightPerDetection = document.getElementById('weightPerDetection').value
	var maximumPerformance = document.getElementById('maximumPerformance').value

	// AJAX codes
	if ( window.XMLHttpRequest )
	{
		// code for modern browsers
		xmlhttp = new XMLHttpRequest()
	}
	else
	{
		// code for old IE browsers
		xmlhttp = new ActiveXObject ( 'Microsoft.XMLHTTP' )
	}

    xmlhttp.onreadystatechange = function()
	{
        if ( this.readyState == 4 && this.status == 200 )
		{
			if ( this.responseText === 'Success' )
			{
				alert ( 'Settings updated successfully to database!' )
				location.reload ( true )
			}
			else
				alert ( this.responseText )
        }
    }

    xmlhttp.open ( 'POST', 'ajax_updateSettings.php', true )
    xmlhttp.setRequestHeader ( 'Content-type', 'application/x-www-form-urlencoded' )
    xmlhttp.send ( 'inTime=' + inTime + '&inTolerance=' + inTolerance + '&outTime=' + outTime + '&outTolerance=' + outTolerance + '&detectionTolerance=' + detectionTolerance + '&weightPerDetection=' + weightPerDetection + '&maximumPerformance=' + maximumPerformance )
	
	return false
}
</script>
<h3>Attendance Settings</h3><br />
<form onsubmit='return SaveSettings()'>
<table width='40%'>
<tr>
	<td width='40%'>In Time:</td>
    <td width='60%'><input type='time' id='inTime' value='<?php echo $inTime; ?>' class='textInputs' required='required' /></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>In Tolerance (minutes):</td>
    <td><input type='number' id='inTolerance' value='<?php echo $inTolerance; ?>' class='textInputs' required='required' /></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Out Time:</td>
    <td><input type='time' id='outTime' value='<?php echo $outTime; ?>' class='textInputs' required='required' /></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Out Tolerance (minutes):</td>
    <td><input type='number' id='outTolerance' value='<?php echo $outTolerance; ?>' class='textInputs' required='required' /></td>
</tr>
</table>
<h3>Resource Usage Settings</h3><br />
<table width='40%'>
<tr>
	<td width='40%'>Detection Tolerance:</td>
    <td width='60%'><input type='number' id='detectionTolerance' value='<?php echo $detectionTolerance; ?>' class='textInputs' required='required' /></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Weight Per Detection (%):</td>
    <td><input type='number' id='weightPerDetection' value='<?php echo $weightPerDetection; ?>' class='textInputs' required='required' /></td>
</tr>
</table>
<h3>Work Delivery Settings</h3><br />
<table width='40%'>
<tr>
	<td width='40%'>Maximum Performance:</td>
    <td width='60%'><input type='number' id='maximumPerformance' value='<?php echo $maximumPerformance; ?>' class='textInputs' required='required' /></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td colspan='2'><input type='submit' value='Save' class='buttons' style='width:200px;height:50px' />&nbsp;<input type='button' value='Back' class='buttons' style='width:200px;height:50px' onclick='history.go(-1)' /></td>
</tr>
</table>
</form>
<?php require ( 'footer.php' ); ?>