<?php
	$reviewDate = $_POST['reviewDate'];
	$employeeID = $_POST['employeeID'];
	$attendancePerformance = $_POST['attendancePerformance'];
	$resourceUsagePerformance = $_POST['resourceUsagePerformance'];
	$workDeliveryPerformance = $_POST['workDeliveryPerformance'];
	$performanceFormula = $_POST['performanceFormula'];
	$finalPerformanceIndex = $_POST['finalPerformanceIndex'];

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT COUNT(*) AS "Exist Count" FROM "Performance Review" WHERE "Review Date"=' . "'$reviewDate' AND \"Employee ID\"='$employeeID'" );

	if ( ReadField ( $result, 0, 'Exist Count' ) > 0 )
	{
		$sql = "UPDATE \"Performance Review\" SET \"Attendance Performance\"=$attendancePerformance,\"Resource Usage Performance\"=$resourceUsagePerformance,\"Work Delivery Performance\"=$workDeliveryPerformance,\"Performance Formula\"='$performanceFormula',\"Final Performance Index\"=$finalPerformanceIndex WHERE \"Review Date\"='$reviewDate' AND \"Employee ID\"='$employeeID'";
	}
	else
	{
		$sql = 'INSERT INTO "Performance Review" ("Review Date","Employee ID","Attendance Performance","Resource Usage Performance","Work Delivery Performance","Performance Formula","Final Performance Index") VALUES ' .
			   "('$reviewDate','$employeeID',$attendancePerformance,$resourceUsagePerformance,$workDeliveryPerformance,'$performanceFormula',$finalPerformanceIndex)";
	}

	QueryDatabase ( $connection, $sql );

	CloseDatabase ( $connection );

	die ( 'Success' );
?>
