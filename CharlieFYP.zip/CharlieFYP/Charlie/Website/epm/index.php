<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.1//EN' 'http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml' lang='en-MY'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' charset='UTF-8' />
<meta name='viewport' content='width=device-width, initial-scale=1.0' />
<title>Employee Performance Manager</title>
<link rel='shortcut icon' type='image/png' href='img/favicon.png' />
<style type='text/css'>
.links:hover { color: red }

.buttons 
{ 
	display: inline-block;
  	padding: 5px 5px;
  	cursor: pointer;
  	text-align: center;
  	text-decoration: none;
  	outline: none;
  	color: #fff;
  	background-color: green;
  	border: none;
  	border-radius: 9px;
  	box-shadow: 0 3px #333;
	width: 200px;
	height: 50px;
}

.buttons:hover {background-color: #8e3e41}

.buttons:active {
  background-color:#333;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}

.textInputs
{
	width:100%;
}
</style>
<script type='text/javascript'>
function Login()
{
	var username = document.getElementById('username').value
	var password = document.getElementById('password').value

	// AJAX codes
	if ( window.XMLHttpRequest )
	{
		// code for modern browsers
		xmlhttp = new XMLHttpRequest()
	}
	else
	{
		// code for old IE browsers
		xmlhttp = new ActiveXObject ( 'Microsoft.XMLHTTP' )
	}

    xmlhttp.onreadystatechange = function()
	{
        if ( this.readyState == 4 && this.status == 200 )
		{
			if ( this.responseText === 'Success' )
				location.href = 'main.php'
			else if ( this.responseText === 'Invalid' )
			    alert ( 'Invalid username and/or password!' )
			else
				alert ( this.responseText )
        }
    }

    xmlhttp.open ( 'POST', 'ajax_performLogin.php', true )
    xmlhttp.setRequestHeader ( 'Content-type', 'application/x-www-form-urlencoded' )
    xmlhttp.send ( 'username=' + username + '&password=' + password )

	return false
}
</script>
</head>

<body>
<center>
<h3><font color='red'>Employee Performance Manager</font></h3>
<br /><form onsubmit='return Login()'>
<table width='30%'>
<tr>
	<td width='40%'>Username:</td>
    <td width='60%'><input type='text' id='username' class='textInputs' required='required' /></td>
</tr>
<tr>
	<td colspan='2'><br /><br /></td>
</tr>
<tr>
	<td>Password:</td>
    <td><input type='password' id='password' class='textInputs' required='required' /></td>
</tr>
<tr>
	<td colspan='2'><br /><br /></td>
</tr>
<tr>
	<td colspan='2'><input type='submit' value='Login' class='buttons' />&nbsp;<input type='reset' value='Clear' class='buttons' /></td>
</tr>
</table>
</form>
<?php require ( 'footer.php' ); ?>