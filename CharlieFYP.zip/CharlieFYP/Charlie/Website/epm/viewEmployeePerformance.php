<?php require ( 'header.php' ); ?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
<script type='text/javascript'>
function Search()
{
	var employeeIDEl = document.getElementById('employeeID')
	var employeeID = employeeIDEl.options [ employeeIDEl.selectedIndex ].value

	var yearEl = document.getElementById('year')
	var year = yearEl.options [ yearEl.selectedIndex ].value

	// AJAX codes
	if ( window.XMLHttpRequest )
	{
		// code for modern browsers
		xmlhttp = new XMLHttpRequest()
	}
	else
	{
		// code for old IE browsers
		xmlhttp = new ActiveXObject ( 'Microsoft.XMLHTTP' )
	}

    xmlhttp.onreadystatechange = function()
	{
        if ( this.readyState == 4 && this.status == 200 )
		{
			document.getElementById('spanPerformanceTable').innerHTML = this.responseText
        }
    }

    xmlhttp.open ( 'POST', 'ajax_generatePerformanceTable.php', true )
    xmlhttp.setRequestHeader ( 'Content-type', 'application/x-www-form-urlencoded' )
    xmlhttp.send ( 'employeeID=' + employeeID + '&year=' + year )
	
	return false
}
</script>
<h3>View Employee Performance</h3>
<form id='frmSearch' onsubmit='return Search()'>
<table width='50%'>
<tr>
	<td width='30%'>Employee ID:</td>
    <td width='40%'><select id='employeeID' class='textInputs'>
    <option value=''>All Employees</option>
    <?php
		require_once ( 'database.php' );

		$connection = OpenDatabase();

		$result = QueryDatabase ( $connection, 'SELECT "Employee ID","Name" FROM "Employee Profile" ORDER BY "Employee ID" ASC' );

		$numEmployees = GetNumRows ( $result );

		for ( $employeeIndex = 0; $employeeIndex < $numEmployees; ++$employeeIndex )
		{
			$employeeID = ReadField ( $result, $employeeIndex, 'Employee ID' );
			$employeeName = ReadField ( $result, $employeeIndex, 'Name' );

			echo "    <option value='$employeeID'>$employeeID ($employeeName)</option>\n";
		}
	?>
    </select></td>
    <td width='30%'><input type='submit' value='Search' class='buttons' style='width:150px;height:30px' /></td>
</tr>
<tr>
	<td>Year:</td>
	<td><select id='year' class='textInputs
	<option value=''>All</option>
	<?php
	for ( $year = 2019; $year >= 2014; --$year )
		echo "    <option value='$year'>$year</option>\n";
	?>
	</select></td>
	<td>&nbsp;</td>
</tr>
</table>
</form><br />
<span id='spanPerformanceTable'><table width='90%' border='1'>
<tr>
	<th>No</th>
    <th>Review Date</th>
    <th>Employee ID</th>
    <th>Name</th>
    <th>Attendance Performance</th>
    <th>Resource Usage Performance</th>
    <th>Work Delivery Performance</th>
    <th>Final Performance</th>
</tr>
<?php
	$result = QueryDatabase ( $connection, 'SELECT to_char("Review Date",\'FMMonth YYYY\') AS "ReviewDate","Performance Review"."Employee ID" AS "Employee ID","Name","Attendance Performance","Resource Usage Performance","Work Delivery Performance","Final Performance Index" FROM "Performance Review" INNER JOIN "Employee Profile" ON "Performance Review"."Employee ID"="Employee Profile"."Employee ID" ORDER BY "Review Date" DESC,"Performance Review"."Employee ID" ASC' );

	$numPerformance = GetNumRows ( $result );

	for ( $performanceIndex = 0; $performanceIndex < $numPerformance; ++$performanceIndex )
	{
		$no = $performanceIndex + 1;
		$reviewDate = ReadField ( $result, $performanceIndex, 'ReviewDate' );
		$employeeID = ReadField ( $result, $performanceIndex, 'Employee ID' );
		$employeeName = ReadField ( $result, $performanceIndex, 'Name' );
		$attendancePerformance = number_format ( ReadField ( $result, $performanceIndex, 'Attendance Performance' ), 0 );
		$resourceUsagePerformance = number_format ( ReadField ( $result, $performanceIndex, 'Resource Usage Performance' ), 0 );
		$workDeliveryPerformance = number_format ( ReadField ( $result, $performanceIndex, 'Work Delivery Performance' ), 0 );
		$finalPerformanceIndex = number_format ( ReadField ( $result, $performanceIndex, 'Final Performance Index' ), 0 );

		echo "<tr align='center'>\n";
		echo "    <td>$no</td>\n";
		echo "    <td>$reviewDate</td>\n";
		echo "    <td>$employeeID</td>\n";
		echo "    <td>$employeeName</td>\n";
		echo "    <td>$attendancePerformance %</td>\n";
		echo "    <td>$resourceUsagePerformance %</td>\n";
		echo "    <td>$workDeliveryPerformance %</td>\n";
		echo "    <td>$finalPerformanceIndex %</td>\n";
		echo "</tr>\n";
	}

	CloseDatabase ( $connection );
?>
</table></span>
<br /><input type='button' value='Back' class='buttons' style='width:150px;height:30px' onclick='history.go(-1)' />
<?php require ( 'footer.php' ); ?>