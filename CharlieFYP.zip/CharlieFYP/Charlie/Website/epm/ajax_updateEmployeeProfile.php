<?php
	$employeeID = $_POST['employeeID'];
	$name = $_POST['name'];
	$dob = $_POST['dob'];
	$gender = $_POST['gender'];
	$position = $_POST['position'];
	$department = $_POST['department'];
	$directManager = $_POST['directManager'];

	$position = str_replace ( '~~', '&', $position );
	$position = str_replace ( '``', '=', $position );
	$position = str_replace ( "'", '`', $position );

	$department = str_replace ( '~~', '&', $department );
	$department = str_replace ( '``', '=', $department );
	$department = str_replace ( "'", '`', $department );

	$directManager = str_replace ( '~~', '&', $directManager );
	$directManager = str_replace ( '``', '=', $directManager );
	$directManager = str_replace ( "'", '`', $directManager );

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT COUNT(*) AS "Exist Count" FROM "Employee Profile" WHERE "Employee ID"=' . "'$employeeID'" );

	if ( ReadField ( $result, 0, 'Exist Count' ) != 1 )
	{
		CloseDatabase ( $connection );
		die ( 'Not Found' );
	}

	$sql = "UPDATE \"Employee Profile\" SET \"Name\"='$name',\"Date of Birth\"='$dob',\"Gender\"='$gender',\"Position\"='$position',\"Department\"='$department',\"Direct Manager\"='$directManager' WHERE \"Employee ID\"='$employeeID'";

	QueryDatabase ( $connection, $sql );

	CloseDatabase ( $connection );

	die ( 'Success' );
?>
