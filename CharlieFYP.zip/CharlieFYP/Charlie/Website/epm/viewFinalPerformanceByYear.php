<?php
	if ( !isset ( $_POST['finalEmployeeIDByYear'] ) || !isset ( $_POST['finalYear'] ) )
		header ( 'Location:employeePerformanceRetrieval.php' );

	require ( 'header.php' );

	$fireHours = 100;

	$employeeID = $_POST['finalEmployeeIDByYear'];
	$year = $_POST['finalYear'];

	require_once ( 'database.php' );

	$connection = OpenDatabase();

	$result = QueryDatabase ( $connection, 'SELECT "In Time","In Tolerance","Out Time","Out Tolerance","Detection Tolerance","Weight Per Detection","Maximum Performance" FROM "System Settings" ORDER BY "ID" DESC LIMIT 1' );

	$inTime = ReadField ( $result, 0, 'In Time' );
	$inTolerance = ReadField ( $result, 0, 'In Tolerance' );
	$outTime = ReadField ( $result, 0, 'Out Time' );
	$outTolerance = ReadField ( $result, 0, 'Out Tolerance' );
	$detectionTolerance = ReadField ( $result, 0, 'Detection Tolerance' );
	$weightPerDetection = ReadField ( $result, 0, 'Weight Per Detection' );
	$maximumPerformance = ReadField ( $result, 0, 'Maximum Performance' );

	$result = QueryDatabase ( $connection, 'SELECT to_char("In"-' . "'$inTime'" . ',\'FMHH24:FMMI\') AS "In Difference",to_char(' . "'$outTime'" . '-"Out",\'FMHH24:FMMI\') AS "Out Difference","Status",to_char("Date",\'FMMM\') AS "Month" FROM "Attendance Information" WHERE to_char("Date",\'YYYY\')=' . "'$year' AND \"Employee ID\"='$employeeID' ORDER BY \"Date\" ASC,\"In\" ASC" );

	$numItemsAttendance = GetNumRows ( $result );

	$goodCount = 0;
	$badCount = 0;

	$arrMonths = Array();

	for ( $itemIndex = 0; $itemIndex < $numItemsAttendance; ++$itemIndex )
	{
		$no = $itemIndex + 1;

		$inDifferenceFields = explode ( ':', ReadField ( $result, $itemIndex, 'In Difference' ) );
		$outDifferenceFields = explode ( ':', ReadField ( $result, $itemIndex, 'Out Difference' ) );
		$status = ReadField ( $result, $itemIndex, 'Status' );
		$month = ReadField ( $result, $itemIndex, 'Month' );
		
		if ( !in_array ( $month, $arrMonths ) )
			$arrMonths[] = $month;

		$inDifference = $inDifferenceFields [ 0 ] * 60 + $inDifferenceFields [ 1 ];
		$outDifference = $outDifferenceFields [ 0 ] * 60 + $outDifferenceFields [ 1 ];

		if ( $inDifference > $inTolerance || $outDifference > $outTolerance )
		{
			if ( $status !== 'Good' )
				++$badCount;
			else
				++$goodCount;
		}
		else
			++$goodCount;
	}

	if ( $numItemsAttendance > 0 )
	{
		$totalCount = $goodCount + $badCount;
		$resultAttendance = ( $totalCount - $badCount ) / $totalCount * 100;
	}

	$resultResource = 0;

	foreach ( $arrMonths as $month )
	{
		$result = QueryDatabase ( $connection, 'SELECT to_char("Date",\'FMDD/FMMM/YYYY\') AS "Performance Date","Detection","Hours","Remark","Status" FROM "Resource Information" WHERE to_char("Date",\'YYYY-FMMM\')=' . "'$year-$month' AND \"Employee ID\"='$employeeID' ORDER BY \"Date\" ASC" );

		$numItemsResource = GetNumRows ( $result );

		$surfHours = 0;

		for ( $itemIndex = 0; $itemIndex < $numItemsResource; ++$itemIndex )
		{
			$no = $itemIndex + 1;
			$date = ReadField ( $result, $itemIndex, 'Performance Date' );
			$detection = ReadField ( $result, $itemIndex, 'Detection' );
			$hours = ReadField ( $result, $itemIndex, 'Hours' );
			$remark = ReadField ( $result, $itemIndex, 'Remark' );
			$status = ReadField ( $result, $itemIndex, 'Status' );

			$surfHours += $hours;
		}

		$badSurfHours = $surfHours * $weightPerDetection - $detectionTolerance;

		if ( $numItemsResource > 0 && $badSurfHours > 0 )
			$resultResource += ( $fireHours - $badSurfHours ) / $fireHours * 100;
		else
			$resultResource += 100;
	}

	$resultResource /= count ( $arrMonths );

	$resultWorkDelivery = 0;
	
	foreach ( $arrMonths as $month )
	{
		$yearMonth = "$year-$month";

		$result = QueryDatabase ( $connection, 'SELECT "Difficulty","Performance" FROM "Work Delivery Information" WHERE to_char("Date",\'YYYY-FMMM\')=' . "'$yearMonth' AND \"Employee ID\"='$employeeID'" );

		$numItemsWorkDelivery = GetNumRows ( $result );

		$score = 0;
		$perfectScore = 0;

		for ( $itemIndex = 0; $itemIndex < $numItemsWorkDelivery; ++$itemIndex )
		{
			$no = $itemIndex + 1;
			$difficulty = ReadField ( $result, $itemIndex, 'Difficulty' );
			$performance = ReadField ( $result, $itemIndex, 'Performance' );

			$score += $difficulty * $performance;
			$perfectScore += $difficulty * $maximumPerformance;
		}

		if ( $numItemsWorkDelivery > 0 )
		{
			$resultWorkDelivery += $score / $perfectScore * 100;
		}
	}
	
	$resultWorkDelivery /= count ( $arrMonths );

	CloseDatabase ( $connection );

	//$resultWorkDelivery = 0;

	//if ( $numItemsWorkDelivery > 0 )
	//	$resultWorkDelivery = $score / $perfectScore * 100;

	$resultFinal = 0.2 * $resultAttendance + 0.3 * $resultResource + 0.5 * $resultWorkDelivery;
?>
<style type='text/css'>
.textInputs
{
	width:100%;
}
</style>
<script type='text/javascript'>
function SavePerformance()
{
	var finalPerformanceFormulaEl = document.getElementById('finalPerformanceFormula')
	var finalPerformanceFormula = finalPerformanceFormulaEl.options [ finalPerformanceFormulaEl.selectedIndex ].value

	// AJAX codes
	if ( window.XMLHttpRequest )
	{
		// code for modern browsers
		xmlhttp = new XMLHttpRequest()
	}
	else
	{
		// code for old IE browsers
		xmlhttp = new ActiveXObject ( 'Microsoft.XMLHTTP' )
	}

    xmlhttp.onreadystatechange = function()
	{
        if ( this.readyState == 4 && this.status == 200 )
		{
			if ( this.responseText === 'Success' )
				alert ( 'Performance review saved successfully to database!' )
			else
				alert ( this.responseText )
        }
    }

    xmlhttp.open ( 'POST', 'ajax_savePerformanceReview.php', true )
    xmlhttp.setRequestHeader ( 'Content-type', 'application/x-www-form-urlencoded' )
    xmlhttp.send ( 'reviewDate=<?php echo $yearMonth . '-01'; ?>&employeeID=<?php echo $employeeID; ?>&attendancePerformance=<?php echo $resultAttendance; ?>&resourceUsagePerformance=<?php echo $resultResource; ?>&workDeliveryPerformance=<?php echo $resultWorkDelivery; ?>&performanceFormula=' + finalPerformanceFormula + '&finalPerformanceIndex=<?php echo $resultFinal; ?>' )

	return false
}
</script>
<h3>Employee Performance Final Index (By Year) for <?php echo $employeeID; ?> for <?php echo "$year"; ?></h3>
<form onsubmit='return SavePerformance()'>
<table width='40%'>
<tr>
	<td width='50%'>Attendance Performance:</td>
    <td width='50%'><?php echo number_format ( $resultAttendance, 0 ) . ' %'; ?></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Resource Usage Performance:</td>
    <td><?php echo number_format ( $resultResource, 0 ) . ' %'; ?></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Work Delivery Performance:</td>
    <td><?php echo number_format ( $resultWorkDelivery, 0 ) . ' %'; ?></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Final Performance Formula:</td>
    <td><select id='finalPerformanceFormula' class='textInputs' required='required'>
    <option value='Standard'>Standard</option>
    </select></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td>Final Performance Index:</td>
    <td><?php echo number_format ( $resultFinal, 0 ) . ' %'; ?></td>
</tr>
<tr>
	<td colspan='2'><br /></td>
</tr>
<tr>
	<td colspan='3'><input type='button' value='Back' class='buttons' style='width:200px;height:50px' onclick='history.go(-1)' /></td>
</tr>
</table>
</form>
<?php require ( 'footer.php' ); ?>